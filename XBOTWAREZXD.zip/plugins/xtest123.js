let handler = async m => {

let intro = `hello bot warez is here`
m.reply(intro)
}
handler.customPrefix = /^(tes|tess|test)$/i
handler.command = new RegExp

module.exports = handler
